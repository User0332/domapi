# domapi

DOM support for Python, as if accessing the JavaScript `document` object. Note that this library is still a work in  progress and does not fully support `document`. This library was built especially for [`pybrowser`](https://github.com/User0332/pybrowser), but it can be used for other projects.
